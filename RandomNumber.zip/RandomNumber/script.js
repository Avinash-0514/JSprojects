function getStarted() {
    let msg1 = "Win";
    let msg2 = "Lost";
    let numVal = parseInt(document.getElementById("playNumber").value);
  var autoGenVal = Math.floor(Math.random() * 11);  
    if (autoGenVal === numVal) {
      document.getElementById("gameResult").innerHTML = msg1;
    } else {
      document.getElementById("gameResult").innerHTML = msg2;
    }
    document.getElementById("generateRandomNum").innerHTML = autoGenVal;
    document.getElementById("generateRandomNum").addEventListener("click", getStarted);
  }
  getStarted()

